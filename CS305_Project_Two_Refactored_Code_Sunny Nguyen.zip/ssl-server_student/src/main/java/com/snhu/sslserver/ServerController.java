package com.snhu.sslserver;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@RestController
public class ServerController {

    private static final char[] HEX = "0123456789ABCDEF".toCharArray();

    private static String sha256(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] out = md.digest(input.getBytes(StandardCharsets.UTF_8));
            return toHex(out);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 not available", e);
        }
    }

    private static String toHex(byte[] bytes) {
        char[] buf = new char[bytes.length * 2];
        for (int i = 0; i < bytes.length; i++) {
            int v = bytes[i] & 0xFF;
            buf[i * 2]     = HEX[v >>> 4];
            buf[i * 2 + 1] = HEX[v & 0x0F];
        }
        return new String(buf);
    }

    @RequestMapping("/hash")
    public String hashPage() {
        // Put YOUR name in here for the screenshot (the rubric wants your name + unique data)
        String data = "Hello World Check Sum! — Sunny Nguyen";
        String hash = sha256(data);
        return "<html><body>" +
               "<p>data: " + data + "</p>" +
               "<p>Name of Cipher Used: SHA-256</p>" +
               "<p>Value: " + hash + "</p>" +
               "</body></html>";
    }
}
